<?php
/**
 * ══════════════════════════════════════════════════════════════════
 * process.php – Bezpečné zpracování kontaktního formuláře
 * ══════════════════════════════════════════════════════════════════
 *
 * BEZPEČNOSTNÍ VRSTVY (OWASP Top 10):
 * 1. Validace HTTP metody (pouze POST)
 * 2. Rate limiting (session-based, 3 zprávy/hod)
 * 3. CSRF token verifikace (timing-safe)
 * 4. Honeypot kontrola (anti-bot)
 * 5. Validace + sanitizace všech vstupů
 * 6. E-mail header injection prevence
 *
 * PHP 8.x required
 */

declare(strict_types=1);

// ─── KONFIGURACE ────────────────────────────────────────────────
// V produkci přesunout do .env souboru mimo web root!
const RECIPIENT_EMAIL  = 'matej.kulisek99@icloud.com';
const SENDER_NAME      = 'Web Portfolio';
const SENDER_EMAIL     = 'noreply@kulisekmatej.cz';
const RATE_LIMIT_MAX   = 3;
const RATE_LIMIT_WINDOW = 3600; // sekundy (1 hodina)

// ─── RESPONSE HEADERS ───────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

// CSRF modul (startuje session)
require_once __DIR__ . '/components/csrf.php';

/**
 * Odešle JSON odpověď a ukončí skript.
 */
function respond(bool $success, string $message, int $code = 200, array $errors = []): never
{
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'errors'  => $errors,
    ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}

// ─── 1. OVĚŘENÍ HTTP METODY ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Neplatná HTTP metoda.', 405);
}

// ─── 2. RATE LIMITING ──────────────────────────────────────────
// Session sliding window – čistíme expirované záznamy, pak kontrolujeme limit.
if (!isset($_SESSION['form_hits']) || !is_array($_SESSION['form_hits'])) {
    $_SESSION['form_hits'] = [];
}

$now = time();
$_SESSION['form_hits'] = array_filter(
    $_SESSION['form_hits'],
    static fn(int $t): bool => ($now - $t) < RATE_LIMIT_WINDOW
);

if (count($_SESSION['form_hits']) >= RATE_LIMIT_MAX) {
    respond(false, 'Příliš mnoho zpráv. Zkuste to za hodinu.', 429);
}

// ─── 3. CSRF TOKEN ─────────────────────────────────────────────
$token = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($token)) {
    respond(false, 'Neplatný bezpečnostní token. Načtěte stránku znovu.', 403);
}

// ─── 4. HONEYPOT ───────────────────────────────────────────────
// Bot vyplnil skryté pole → simulujeme úspěch (fail silently)
if (!empty($_POST['website_url'] ?? '')) {
    respond(true, 'Děkuji za zprávu! Ozvu se co nejdříve.');
}

// ─── 5. VALIDACE + SANITIZACE ──────────────────────────────────
$errors = [];

// Jméno
$name = mb_substr(trim($_POST['name'] ?? ''), 0, 100, 'UTF-8');
$name = htmlspecialchars($name, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
if (mb_strlen($name) < 2) {
    $errors['name'] = 'Jméno musí mít alespoň 2 znaky.';
}

// E-mail
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Zadejte platnou e-mailovou adresu.';
} elseif (mb_strlen($email) > 254) {
    $errors['email'] = 'E-mail je příliš dlouhý.';
}

// Služba (whitelist)
$allowedServices = ['personal', 'business', 'eshop', 'other'];
$service = $_POST['service'] ?? '';
if (!in_array($service, $allowedServices, true)) {
    $errors['service'] = 'Vyberte platný typ služby.';
}

// Zpráva
$message = mb_substr(trim($_POST['message'] ?? ''), 0, 5000, 'UTF-8');
$message = htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
if (mb_strlen($message) < 10) {
    $errors['message'] = 'Zpráva musí mít alespoň 10 znaků.';
}

// Vrátit chyby
if (!empty($errors)) {
    respond(false, 'Formulář obsahuje chyby.', 422, $errors);
}

// ─── 6. SESTAVENÍ A ODESLÁNÍ E-MAILU ───────────────────────────
$serviceLabels = [
    'personal' => 'Osobní web',
    'business' => 'Firemní prezentace',
    'eshop'    => 'E-shop řešení',
    'other'    => 'Jiné / Konzultace',
];
$serviceLabel = $serviceLabels[$service] ?? 'Neuvedeno';
$datetime     = date('d.m.Y H:i:s');
$clientIp     = htmlspecialchars(
    $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    ENT_QUOTES, 'UTF-8'
);

$body = implode("\n", [
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
    "  NOVÁ POPTÁVKA Z WEBU",
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
    "",
    "Jméno:    {$name}",
    "E-mail:   {$email}",
    "Služba:   {$serviceLabel}",
    "",
    "Zpráva:",
    $message,
    "",
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
    "Odesláno:  {$datetime}",
    "IP adresa: {$clientIp}",
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
]);

// UTF-8 kódovaný předmět (RFC 2047)
$subject = "=?UTF-8?B?" . base64_encode("[Web] Poptávka: {$serviceLabel} – {$name}") . "?=";

$headers = implode("\r\n", [
    "From: " . SENDER_NAME . " <" . SENDER_EMAIL . ">",
    "Reply-To: {$name} <{$email}>",
    "Content-Type: text/plain; charset=UTF-8",
    "X-Mailer: PHP/" . phpversion(),
]);

$sent = mail(RECIPIENT_EMAIL, $subject, $body, $headers);

if ($sent) {
    $_SESSION['form_hits'][] = $now;
    regenerateCsrfToken(); // Single-use token

    respond(true, 'Děkuji za zprávu! Ozvu se do 24 hodin.');
} else {
    error_log("[FORM] mail() failed: {$email} at {$datetime}");
    respond(false, 'Odeslání se nezdařilo. Napište přímo na e-mail.', 500);
}
