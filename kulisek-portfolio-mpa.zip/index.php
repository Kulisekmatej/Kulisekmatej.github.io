<?php
/**
 * index.php – Hlavní stránka (Homepage)
 *
 * OBSAH: Hero sekce → Zkrácený přehled služeb (3) → 2 nejlepší projekty → CTA
 * SEO: Obsahuje JSON-LD strukturovaná data (vložená v header.php)
 *
 * ARCHITEKTURA: Stránka nastaví meta-data a pak includuje header/footer.
 * Veškerá data jsou inline (žádná DB) → snadno editovatelná, rychlé načtení.
 */

// Meta-data pro header.php
$pageTitle       = 'Matěj Kulíšek | Tvorba webů, SEO & IT bezpečnost';
$pageDescription = 'Tvořím rychlé, bezpečné a SEO-optimalizované webové stránky na míru. Landing pages, firemní weby a e-shopy.';
$currentPage     = 'home';

require_once __DIR__ . '/components/header.php';
?>

<!-- ═══════════════════════════════════════════════════════════════
     HERO SEKCE
═══════════════════════════════════════════════════════════════ -->
<section class="relative min-h-screen flex items-center justify-center overflow-hidden pt-16"
         aria-labelledby="hero-heading">

    <!-- Dekorativní efekty (skryté pro asistivní technologie) -->
    <div class="hero-glow top-1/3 left-1/2" aria-hidden="true"></div>
    <div class="absolute inset-0 opacity-[0.03]" aria-hidden="true"
         style="background-image: linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px);
                background-size: 64px 64px;"></div>

    <div class="relative z-10 max-w-4xl mx-auto px-6 text-center">

        <!-- Status badge -->
        <div data-reveal class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-2 mb-8"
             style="background: rgba(0,220,130,0.06);">
            <span class="w-2 h-2 rounded-full bg-accent animate-pulse" aria-hidden="true"></span>
            <span class="font-mono text-xs text-accent tracking-wide">CCNA · CompTIA Security+ · OSVČ</span>
        </div>

        <!-- H1 – hlavní nadpis (SEO) -->
        <h1 id="hero-heading" data-reveal data-reveal-delay="1"
            class="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.08] tracking-tight mb-6">
            Tvořím weby, které<br>
            <span class="italic text-accent">přinášejí zákazníky</span>
        </h1>

        <p data-reveal data-reveal-delay="2"
           class="text-lg sm:text-xl text-text-2 max-w-2xl mx-auto mb-10 leading-relaxed">
            Rychlé, bezpečné a SEO-optimalizované webové stránky na míru.
            Od landing pages po e-shopy — s&nbsp;důrazem na výsledky, ne jen design.
        </p>

        <!-- CTA -->
        <div data-reveal data-reveal-delay="3" class="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="/kontakt" class="btn btn--primary text-base">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon" aria-hidden="true">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                Poptat web zdarma
            </a>
            <a href="/portfolio" class="btn btn--secondary text-base">
                Prohlédnout projekty
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon" aria-hidden="true">
                    <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
                </svg>
            </a>
        </div>

        <!-- Trust signály -->
        <div data-reveal data-reveal-delay="3"
             class="mt-16 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-text-3">
            <?php
            $trustItems = ['Lighthouse 95+', 'HTTPS & audit', 'Bez měsíčních poplatků'];
            foreach ($trustItems as $item): ?>
            <span class="flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
                     class="text-accent" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                <?= htmlspecialchars($item, ENT_QUOTES, 'UTF-8') ?>
            </span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     SLUŽBY – ZKRÁCENÝ PŘEHLED (3 karty)
═══════════════════════════════════════════════════════════════ -->
<section class="py-24 sm:py-32" aria-labelledby="services-heading">
    <div class="max-w-6xl mx-auto px-6">

        <div data-reveal class="mb-14 max-w-2xl">
            <hr class="section-line mb-6" aria-hidden="true">
            <h2 id="services-heading" class="font-display text-3xl sm:text-4xl md:text-5xl leading-tight mb-4">
                Co pro vás mohu <span class="italic text-accent">vytvořit</span>
            </h2>
            <p class="text-text-2 text-lg">
                Tři základní balíčky. Každý postavený na rychlosti, SEO a bezpečném kódu.
            </p>
        </div>

        <?php
        // Definice služeb – data oddělená od šablony
        $services = [
            [
                'icon'     => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>',
                'title'    => 'Osobní web',
                'desc'     => 'Rychlá, konverzní stránka pro freelancery a kampaně.',
                'features' => ['Responzivní design', 'SEO + Analytics', 'Kontaktní formulář'],
                'price'    => 'od 12 000 Kč',
                'featured' => false,
            ],
            [
                'icon'     => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
                'title'    => 'Firemní prezentace',
                'desc'     => 'Kompletní web, který buduje důvěru a přivádí zákazníky.',
                'features' => ['Až 8 podstránek', 'CMS pro správu', 'Google Business + SEO'],
                'price'    => 'od 30 000 Kč',
                'featured' => true,
            ],
            [
                'icon'     => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
                'title'    => 'E-shop řešení',
                'desc'     => 'E-shop s platební bránou a automatizací objednávek.',
                'features' => ['Platební brána', 'Správa produktů', 'Dopravci (Zásilkovna, PPL)'],
                'price'    => 'od 60 000 Kč',
                'featured' => false,
            ],
        ];
        ?>

        <div class="grid md:grid-cols-3 gap-6">
            <?php foreach ($services as $i => $svc): ?>
            <article data-reveal data-reveal-delay="<?= $i + 1 ?>"
                     class="card flex flex-col <?= $svc['featured'] ? 'card--featured' : '' ?>">

                <?php if ($svc['featured']): ?>
                <div class="absolute -top-3 left-6">
                    <span class="badge badge--accent text-[10px] font-semibold uppercase tracking-wider">Nejoblíbenější</span>
                </div>
                <?php endif; ?>

                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-surface-3 flex items-center justify-center" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="1.5" class="text-accent"><?= $svc['icon'] ?></svg>
                    </div>
                    <h3 class="font-display text-xl"><?= htmlspecialchars($svc['title']) ?></h3>
                </div>

                <p class="text-text-2 text-sm mb-6 flex-grow"><?= htmlspecialchars($svc['desc']) ?></p>

                <ul class="space-y-2 mb-8 text-sm" aria-label="Součásti balíčku">
                    <?php foreach ($svc['features'] as $f): ?>
                    <li class="flex items-start gap-2.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2" class="check-icon" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                        <?= htmlspecialchars($f) ?>
                    </li>
                    <?php endforeach; ?>
                </ul>

                <div class="mt-auto pt-6 border-t border-border-1">
                    <span class="font-mono text-2xl"><?= htmlspecialchars($svc['price']) ?></span>
                </div>
            </article>
            <?php endforeach; ?>
        </div>

        <div data-reveal class="text-center mt-10">
            <a href="/sluzby" class="btn btn--secondary">
                Detailní přehled služeb
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon" aria-hidden="true">
                    <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
                </svg>
            </a>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     PORTFOLIO – NÁHLED 2 NEJLEPŠÍCH PROJEKTŮ
═══════════════════════════════════════════════════════════════ -->
<section class="py-24 sm:py-32 border-t border-border-1" aria-labelledby="portfolio-preview-heading">
    <div class="max-w-6xl mx-auto px-6">

        <div data-reveal class="mb-14 max-w-2xl">
            <hr class="section-line mb-6" aria-hidden="true">
            <h2 id="portfolio-preview-heading" class="font-display text-3xl sm:text-4xl md:text-5xl leading-tight mb-4">
                Vybrané <span class="italic text-accent">projekty</span>
            </h2>
            <p class="text-text-2 text-lg">Problém → Řešení → Měřitelný výsledek.</p>
        </div>

        <div class="grid md:grid-cols-2 gap-6">

            <!-- Projekt 1 -->
            <article data-reveal data-reveal-delay="1" class="card">
                <div class="aspect-video rounded-lg mb-5 bg-surface-3 relative overflow-hidden"
                     role="img" aria-label="Náhled webu Airless Malby Kreisinger">
                    <div class="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent"></div>
                    <div class="absolute bottom-3 left-3 flex gap-1.5">
                        <span class="badge text-[10px]">HTML5</span>
                        <span class="badge text-[10px]">CSS3</span>
                        <span class="badge text-[10px]">SEO</span>
                    </div>
                </div>
                <span class="badge badge--accent text-[10px] mb-3">Firemní web</span>
                <h3 class="font-display text-xl mb-3">Airless Malby Kreisinger</h3>
                <div class="space-y-2.5 text-sm text-text-2 mb-5">
                    <p><span class="font-mono text-[10px] text-text-3 uppercase tracking-wider">Problém:</span>
                       Firma bez webu přicházela o zakázky.</p>
                    <p><span class="font-mono text-[10px] text-text-3 uppercase tracking-wider">Řešení:</span>
                       Responzivní web + lokální SEO + Google Business.</p>
                    <p><span class="font-mono text-[10px] text-text-3 uppercase tracking-wider">Výsledek:</span>
                       12+ poptávek/měsíc, Lighthouse 96+.</p>
                </div>
                <div class="grid grid-cols-3 gap-3 pt-5 border-t border-border-1">
                    <div class="text-center"><div class="metric text-lg">96+</div><div class="text-[11px] text-text-3 mt-0.5">Lighthouse</div></div>
                    <div class="text-center"><div class="metric text-lg">&lt;1.5s</div><div class="text-[11px] text-text-3 mt-0.5">Načtení</div></div>
                    <div class="text-center"><div class="metric text-lg">12+</div><div class="text-[11px] text-text-3 mt-0.5">Poptávek/m</div></div>
                </div>
            </article>

            <!-- Projekt 2 -->
            <article data-reveal data-reveal-delay="2" class="card">
                <div class="aspect-video rounded-lg mb-5 bg-surface-3 relative overflow-hidden"
                     role="img" aria-label="Bezpečnostní audit školního webu">
                    <div class="absolute inset-0 bg-gradient-to-br from-red-500/10 to-transparent"></div>
                    <div class="absolute bottom-3 left-3 flex gap-1.5">
                        <span class="badge text-[10px]">Kali</span>
                        <span class="badge text-[10px]">OWASP</span>
                        <span class="badge text-[10px]">Nmap</span>
                    </div>
                </div>
                <span class="badge badge--accent text-[10px] mb-3">Cybersecurity</span>
                <h3 class="font-display text-xl mb-3">Bezpečnostní audit – škola</h3>
                <div class="space-y-2.5 text-sm text-text-2 mb-5">
                    <p><span class="font-mono text-[10px] text-text-3 uppercase tracking-wider">Problém:</span>
                       Joomla web s neznámým bezpečnostním stavem.</p>
                    <p><span class="font-mono text-[10px] text-text-3 uppercase tracking-wider">Řešení:</span>
                       Autorizovaný pentest + report + doporučení.</p>
                    <p><span class="font-mono text-[10px] text-text-3 uppercase tracking-wider">Výsledek:</span>
                       7 zranitelností nalezeno, 100 % opraveno.</p>
                </div>
                <div class="grid grid-cols-3 gap-3 pt-5 border-t border-border-1">
                    <div class="text-center"><div class="metric text-lg">7</div><div class="text-[11px] text-text-3 mt-0.5">Nálezy</div></div>
                    <div class="text-center"><div class="metric text-lg">2</div><div class="text-[11px] text-text-3 mt-0.5">Kritické</div></div>
                    <div class="text-center"><div class="metric text-lg">100%</div><div class="text-[11px] text-text-3 mt-0.5">Opraveno</div></div>
                </div>
            </article>
        </div>

        <div data-reveal class="text-center mt-10">
            <a href="/portfolio" class="btn btn--secondary">
                Všechny projekty
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon" aria-hidden="true">
                    <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
                </svg>
            </a>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     CTA BANNER
═══════════════════════════════════════════════════════════════ -->
<section class="py-24 border-t border-border-1" aria-labelledby="cta-heading">
    <div data-reveal class="max-w-3xl mx-auto px-6 text-center">
        <h2 id="cta-heading" class="font-display text-3xl sm:text-4xl leading-tight mb-4">
            Připravený na nový <span class="italic text-accent">web?</span>
        </h2>
        <p class="text-text-2 text-lg mb-8 max-w-xl mx-auto">
            Popište svůj projekt a do 24 hodin se vám ozvu s&nbsp;nezávaznou nabídkou. Žádné poplatky za konzultaci.
        </p>
        <a href="/kontakt" class="btn btn--primary text-base">Nezávazná poptávka</a>
    </div>
</section>

<?php require_once __DIR__ . '/components/footer.php'; ?>
