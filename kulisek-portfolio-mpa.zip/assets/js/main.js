/**
 * ══════════════════════════════════════════════════════════════════
 * main.js – Interaktivita webu (Vanilla ES6+, < 7 KB)
 * ══════════════════════════════════════════════════════════════════
 *
 * MODULY:
 * 1. Scroll-triggered animace (IntersectionObserver)
 * 2. Mobilní navigace (hamburger)
 * 3. Klientská validace formuláře
 * 4. Async odeslání formuláře (fetch API → PHP)
 * 5. Toast notifikace
 * 6. Utility (rok ve footeru, smooth scroll)
 */

'use strict';

// ─── Helpers ────────────────────────────────────────────────────
const qs  = (sel, ctx = document) => ctx.querySelector(sel);
const qsa = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

// ═══════════════════════════════════════════════════════════════
// 1. SCROLL ANIMACE (IntersectionObserver)
// ═══════════════════════════════════════════════════════════════
// IntersectionObserver je asynchronní → nblokuje main thread.
// Respektuje prefers-reduced-motion (WCAG 2.3.3).
function initReveal() {
    const els = qsa('[data-reveal]');
    if (!els.length) return;

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        els.forEach(el => el.classList.add('is-visible'));
        return;
    }

    const observer = new IntersectionObserver(
        entries => entries.forEach(e => {
            if (e.isIntersecting) {
                e.target.classList.add('is-visible');
                observer.unobserve(e.target);
            }
        }),
        { rootMargin: '-50px', threshold: 0.1 }
    );

    els.forEach(el => observer.observe(el));
}

// ═══════════════════════════════════════════════════════════════
// 2. MOBILNÍ MENU
// ═══════════════════════════════════════════════════════════════
function initMobile() {
    const btn  = qs('#hamburger-btn');
    const menu = qs('#mobile-menu');
    if (!btn || !menu) return;

    let open = false;

    function toggle() {
        open = !open;
        btn.classList.toggle('is-active', open);
        menu.classList.toggle('is-open', open);
        menu.setAttribute('aria-hidden', String(!open));
        btn.setAttribute('aria-expanded', String(open));
        btn.setAttribute('aria-label', open ? 'Zavřít menu' : 'Otevřít menu');
        document.body.style.overflow = open ? 'hidden' : '';
    }

    btn.addEventListener('click', toggle);
    qsa('[data-mobile-link]', menu).forEach(a => a.addEventListener('click', () => open && toggle()));
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && open) { toggle(); btn.focus(); } });
}

// ═══════════════════════════════════════════════════════════════
// 3. KLIENTSKÁ VALIDACE
// ═══════════════════════════════════════════════════════════════
// UPOZORNĚNÍ: Toto je pouze UX vrstva! Server provede vlastní
// validaci (process.php) – klientskou validaci lze obejít.

const rules = {
    name: [
        { test: v => v.trim().length >= 2,   msg: 'Jméno musí mít alespoň 2 znaky.' },
        { test: v => v.trim().length <= 100,  msg: 'Jméno je příliš dlouhé.' },
    ],
    email: [
        { test: v => v.trim().length > 0,                          msg: 'Zadejte e-mail.' },
        { test: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()), msg: 'Neplatný formát e-mailu.' },
    ],
    service: [
        { test: v => ['personal','business','eshop','other'].includes(v), msg: 'Vyberte službu.' },
    ],
    message: [
        { test: v => v.trim().length >= 10,   msg: 'Zpráva musí mít alespoň 10 znaků.' },
        { test: v => v.trim().length <= 5000,  msg: 'Zpráva je příliš dlouhá.' },
    ],
};

function validate(field, value) {
    for (const r of (rules[field] || [])) {
        if (!r.test(value)) return r.msg;
    }
    return '';
}

function showError(field, msg) {
    const input = qs(`#${field}`);
    const error = qs(`#${field}-error`);
    if (!input || !error) return;

    if (msg) {
        input.classList.add('is-error');
        input.setAttribute('aria-invalid', 'true');
        error.textContent = msg;
        error.classList.add('is-visible');
    } else {
        input.classList.remove('is-error');
        input.setAttribute('aria-invalid', 'false');
        error.textContent = '';
        error.classList.remove('is-visible');
    }
}

function validateAll() {
    const fields = ['name', 'email', 'service', 'message'];
    let ok = true;
    fields.forEach(f => {
        const el = qs(`#${f}`);
        if (!el) return;
        const msg = validate(f, el.value);
        showError(f, msg);
        if (msg) ok = false;
    });
    return ok;
}

// ═══════════════════════════════════════════════════════════════
// 4. ASYNCHRONNÍ ODESLÁNÍ FORMULÁŘE
// ═══════════════════════════════════════════════════════════════
function initForm() {
    const form = qs('#contact-form');
    if (!form) return; // Formulář je jen na /kontakt

    const btnSubmit = qs('#submit-btn');
    const btnText   = qs('#submit-text');
    const btnSpin   = qs('#submit-spinner');
    const counter   = qs('#message-counter');
    const textarea  = qs('#message');

    // Počítadlo znaků
    if (textarea && counter) {
        textarea.addEventListener('input', () => {
            const n = textarea.value.length;
            counter.textContent = `${n} / 5000`;
            counter.style.color = n > 4500 ? 'var(--danger)' : '';
        });
    }

    // Real-time validace (blur + input)
    ['name', 'email', 'service', 'message'].forEach(f => {
        const el = qs(`#${f}`);
        if (!el) return;

        el.addEventListener('blur', () => {
            if (el.value.trim() || f === 'service') {
                showError(f, validate(f, el.value));
            }
        });
        el.addEventListener('input', () => {
            if (!validate(f, el.value)) showError(f, '');
        });
    });

    // Submit handler
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (!validateAll()) {
            const first = qs('.form-field.is-error');
            if (first) first.focus();
            return;
        }

        // Loading stav
        btnSubmit.disabled = true;
        btnText.textContent = 'Odesílám…';
        btnSpin.classList.remove('hidden');

        try {
            const res  = await fetch(form.action, {
                method: 'POST',
                body: new FormData(form),
                credentials: 'same-origin',
            });
            const data = await res.json();

            if (data.success) {
                toast(data.message, 'success');
                form.reset();
                if (counter) counter.textContent = '0 / 5000';
            } else {
                if (data.errors && typeof data.errors === 'object') {
                    Object.entries(data.errors).forEach(([f, m]) => showError(f, m));
                }
                toast(data.message || 'Něco se pokazilo.', 'error');
            }
        } catch {
            toast('Nepodařilo se odeslat. Zkontrolujte připojení.', 'error');
        } finally {
            btnSubmit.disabled = false;
            btnText.textContent = 'Odeslat poptávku';
            btnSpin.classList.add('hidden');
        }
    });
}

// ═══════════════════════════════════════════════════════════════
// 5. TOAST NOTIFIKACE
// ═══════════════════════════════════════════════════════════════
let toastTimer = null;

function toast(msg, type = 'success', ms = 5000) {
    const el = qs('#toast');
    if (!el) return;
    if (toastTimer) clearTimeout(toastTimer);

    el.textContent = msg;
    el.className = `toast toast--${type}`;
    void el.offsetHeight; // reflow pro restart animace
    el.classList.add('is-visible');

    toastTimer = setTimeout(() => el.classList.remove('is-visible'), ms);
}

// ═══════════════════════════════════════════════════════════════
// 6. UTILITY
// ═══════════════════════════════════════════════════════════════
function initUtils() {
    // Rok ve footeru
    const y = qs('#footer-year');
    if (y) y.textContent = new Date().getFullYear().toString();

    // Smooth scroll pro anchor linky (s offset pro fixed nav)
    qsa('a[href^="#"]').forEach(a => {
        a.addEventListener('click', e => {
            const id = a.getAttribute('href');
            if (!id || id === '#') return;
            const target = qs(id);
            if (!target) return;
            e.preventDefault();
            window.scrollTo({
                top: target.getBoundingClientRect().top + window.scrollY - 72,
                behavior: 'smooth',
            });
            history.pushState(null, '', id);
        });
    });
}

// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
    initReveal();
    initMobile();
    initForm();
    initUtils();
});
