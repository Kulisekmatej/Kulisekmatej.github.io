<?php
/**
 * sluzby.php – Detailní přehled služeb a ceník
 *
 * URL: /sluzby (koncovka .php skryta přes .htaccess)
 * OBSAH: 3 balíčky s plným výčtem features → Jak spolupracujeme (proces)
 */

$pageTitle       = 'Služby & Ceník | Matěj Kulíšek';
$pageDescription = 'Osobní weby, firemní prezentace a e-shopy na míru. Detailní přehled balíčků, ceník a popis procesu spolupráce.';
$currentPage     = 'sluzby';

require_once __DIR__ . '/components/header.php';

// ─── DATA: Služby (plný detail) ─────────────────────────────────
$packages = [
    [
        'icon'  => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>',
        'title' => 'Osobní web',
        'desc'  => 'Jednoduchá, rychlá stránka zaměřená na konverzi. Ideální pro freelancery, kampaně nebo osobní branding.',
        'features' => [
            'Responzivní design (mobile-first)',
            'Core Web Vitals optimalizace',
            'Kontaktní formulář s validací',
            'Základní SEO nastavení',
            'Google Analytics 4 integrace',
            'SSL certifikát (HTTPS)',
            'Základní bezpečnostní hlavičky',
        ],
        'price' => 'od 12 000 Kč',
        'time'  => '5–10 dní',
        'featured' => false,
    ],
    [
        'icon'  => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'title' => 'Firemní prezentace',
        'desc'  => 'Kompletní webová prezentace budující důvěru. Profesionální řešení na míru vašemu podnikání.',
        'features' => [
            'Vše z balíčku Osobní web',
            'Až 8 podstránek na míru',
            'Pokročilé SEO + strukturovaná data',
            'Google Business profil integrace',
            'CMS pro snadnou správu obsahu',
            'Bezpečnostní audit (OWASP)',
            'Optimalizace konverzí (CRO)',
            'E-mailové notifikace',
        ],
        'price' => 'od 30 000 Kč',
        'time'  => '2–4 týdny',
        'featured' => true,
    ],
    [
        'icon'  => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
        'title' => 'E-shop řešení',
        'desc'  => 'Plnohodnotný e-shop s platební bránou, správou produktů a automatizací objednávek.',
        'features' => [
            'Vše z Firemní prezentace',
            'Platební brána (GoPay / Stripe)',
            'Správa produktů a kategorií',
            'Automatické e-mailové notifikace',
            'Integrace dopravců (Zásilkovna, PPL)',
            'Skladové hospodářství',
            'Měsíční bezpečnostní monitoring',
            'GDPR compliance',
        ],
        'price' => 'od 60 000 Kč',
        'time'  => '4–8 týdnů',
        'featured' => false,
    ],
];

// ─── DATA: Proces spolupráce ────────────────────────────────────
$process = [
    ['num' => '01', 'title' => 'Konzultace',    'desc' => 'Zmapujeme vaše potřeby, cíle a cílovou skupinu. Zdarma a nezávazně.'],
    ['num' => '02', 'title' => 'Návrh & Design', 'desc' => 'Připravím wireframe a vizuální návrh. Odsouhlasíme si směr.'],
    ['num' => '03', 'title' => 'Vývoj & Testy',  'desc' => 'Kóduji, testuji, optimalizuji. Průběžně ukazuji postup.'],
    ['num' => '04', 'title' => 'Spuštění',       'desc' => 'Nasadíme web, nastavíme analytics a SEO. Předám kompletní dokumentaci.'],
];
?>

<!-- ═══ HERO (stránka služeb) ═══ -->
<section class="pt-32 pb-20" aria-labelledby="sluzby-heading">
    <div class="max-w-6xl mx-auto px-6">
        <div data-reveal class="max-w-2xl">
            <hr class="section-line mb-6" aria-hidden="true">
            <h1 id="sluzby-heading" class="font-display text-4xl sm:text-5xl md:text-6xl leading-tight mb-5">
                Služby <span class="italic text-accent">&amp; Ceník</span>
            </h1>
            <p class="text-text-2 text-lg leading-relaxed">
                Každý projekt stavím na třech pilířích: <strong class="text-text-1">rychlost</strong>,
                <strong class="text-text-1">viditelnost ve vyhledávačích</strong> a
                <strong class="text-text-1">bezpečný kód</strong>. Žádné šablony — vše na míru.
            </p>
        </div>
    </div>
</section>

<!-- ═══ BALÍČKY (detailní) ═══ -->
<section class="pb-24 sm:pb-32" aria-label="Přehled balíčků">
    <div class="max-w-6xl mx-auto px-6">
        <div class="grid md:grid-cols-3 gap-6">
            <?php foreach ($packages as $i => $pkg): ?>
            <article data-reveal data-reveal-delay="<?= $i + 1 ?>"
                     class="card flex flex-col relative <?= $pkg['featured'] ? 'card--featured' : '' ?>">

                <?php if ($pkg['featured']): ?>
                <div class="absolute -top-3 left-6">
                    <span class="badge badge--accent text-[10px] font-semibold uppercase tracking-wider">Nejoblíbenější</span>
                </div>
                <?php endif; ?>

                <!-- Hlavička karty -->
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-surface-3 flex items-center justify-center" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="1.5" class="text-accent"><?= $pkg['icon'] ?></svg>
                    </div>
                    <h2 class="font-display text-xl"><?= htmlspecialchars($pkg['title']) ?></h2>
                </div>

                <p class="text-text-2 text-sm leading-relaxed mb-6 flex-grow">
                    <?= htmlspecialchars($pkg['desc']) ?>
                </p>

                <!-- Features -->
                <ul class="space-y-2.5 mb-8 text-sm" aria-label="Součásti balíčku">
                    <?php foreach ($pkg['features'] as $f): ?>
                    <li class="flex items-start gap-2.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2" class="check-icon" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                        <?= htmlspecialchars($f) ?>
                    </li>
                    <?php endforeach; ?>
                </ul>

                <!-- Cena a čas -->
                <div class="mt-auto pt-6 border-t border-border-1 flex items-end justify-between">
                    <div>
                        <div class="font-mono text-2xl"><?= htmlspecialchars($pkg['price']) ?></div>
                        <div class="text-text-3 text-xs mt-1">Dodání: <?= htmlspecialchars($pkg['time']) ?></div>
                    </div>
                    <a href="/kontakt" class="btn btn--primary text-sm !py-2 !px-4">Poptat</a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══ JAK SPOLUPRACUJEME (proces) ═══ -->
<section class="py-24 sm:py-32 border-t border-border-1" aria-labelledby="process-heading">
    <div class="max-w-6xl mx-auto px-6">

        <div data-reveal class="mb-14 max-w-2xl">
            <hr class="section-line mb-6" aria-hidden="true">
            <h2 id="process-heading" class="font-display text-3xl sm:text-4xl md:text-5xl leading-tight mb-4">
                Jak <span class="italic text-accent">spolupracujeme</span>
            </h2>
            <p class="text-text-2 text-lg">Od první konzultace po spuštění — transparentně a efektivně.</p>
        </div>

        <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php foreach ($process as $i => $step): ?>
            <div data-reveal data-reveal-delay="<?= $i + 1 ?>"
                 class="relative p-6 rounded-xl border border-border-1 bg-surface-2">
                <span class="font-mono text-4xl font-bold text-accent/20 absolute top-4 right-5"
                      aria-hidden="true"><?= $step['num'] ?></span>
                <h3 class="font-display text-lg mb-2 relative z-10"><?= htmlspecialchars($step['title']) ?></h3>
                <p class="text-text-2 text-sm relative z-10"><?= htmlspecialchars($step['desc']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="py-20 border-t border-border-1" aria-labelledby="cta-sluzby-heading">
    <div data-reveal class="max-w-3xl mx-auto px-6 text-center">
        <h2 id="cta-sluzby-heading" class="font-display text-3xl sm:text-4xl leading-tight mb-4">
            Nevíte, který balíček <span class="italic text-accent">vybrat?</span>
        </h2>
        <p class="text-text-2 text-lg mb-8">Ozvěte se a společně najdeme to pravé řešení.</p>
        <a href="/kontakt" class="btn btn--primary text-base">Nezávazná konzultace</a>
    </div>
</section>

<?php require_once __DIR__ . '/components/footer.php'; ?>
