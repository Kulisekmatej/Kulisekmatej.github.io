<?php
/**
 * components/header.php – Sdílená hlavička pro všechny stránky
 *
 * ARCHITEKTURA:
 * Každá stránka nastaví proměnné $pageTitle a $pageDescription PŘED
 * includováním tohoto souboru. Header je "controller-aware" – ví,
 * na které stránce se nachází, a zvýrazní příslušný odkaz v navigaci.
 *
 * POUŽITÍ:
 *   $pageTitle = 'Služby';
 *   $pageDescription = 'Přehled nabízených služeb...';
 *   $currentPage = 'sluzby';
 *   require_once __DIR__ . '/components/header.php';
 */

declare(strict_types=1);

// Výchozí hodnoty pokud stránka nenastaví proměnné
$pageTitle       = $pageTitle ?? 'Matěj Kulíšek | Tvorba webů & IT řešení';
$pageDescription = $pageDescription ?? 'Rychlé, bezpečné a SEO-optimalizované webové stránky na míru.';
$currentPage     = $currentPage ?? 'home';

// CSRF token pro formuláře (session se startuje v csrf.php)
require_once __DIR__ . '/csrf.php';

/**
 * Helper: vrátí CSS třídu pro aktivní odkaz v navigaci.
 * Oddělení logiky od šablony → čistší HTML.
 */
function navActiveClass(string $page, string $current): string
{
    return $page === $current ? 'nav-link nav-link--active' : 'nav-link';
}
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="author" content="Matěj Kulíšek">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:title" content="<?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:description" content="<?= htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="cs_CZ">

    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>

    <!-- Favicon -->
    <link rel="icon" href="/assets/icons/favicon.svg" type="image/svg+xml">

    <!-- Fonty – preconnect pro rychlejší LCP -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <!-- Tailwind CDN (pro produkci: zkompilovat přes CLI) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    surface:  { 1: '#08090B', 2: '#0F1115', 3: '#171A20', 4: '#1E222A' },
                    text:     { 1: '#EDEEF0', 2: '#8C919B', 3: '#505660' },
                    accent:   { DEFAULT: '#00DC82', dim: '#00DC8226', hover: '#00C472' },
                    danger:   '#FF4D5A',
                    border:   { 1: '#ffffff0F', 2: '#ffffff1A' },
                },
                fontFamily: {
                    display: ['"Instrument Serif"', 'Georgia', 'serif'],
                    body:    ['"DM Sans"', 'system-ui', 'sans-serif'],
                    mono:    ['"JetBrains Mono"', 'monospace'],
                },
            }
        }
    }
    </script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">

    <!-- Structured Data (JSON-LD) – pouze na hlavní stránce -->
    <?php if ($currentPage === 'home'): ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Matěj Kulíšek – Tvorba webů",
        "description": "Tvorba webových stránek, SEO optimalizace a IT bezpečnostní řešení.",
        "url": "https://kulisekmatej.cz",
        "email": "matej.kulisek99@icloud.com",
        "areaServed": "CZ",
        "priceRange": "$$",
        "knowsAbout": ["Web Development", "SEO", "Cybersecurity"]
    }
    </script>
    <?php endif; ?>
</head>

<body class="bg-surface-1 text-text-1 font-body antialiased leading-relaxed">

    <!-- ═══ SKIP LINK (WCAG 2.4.1 – klávesová navigace) ═══ -->
    <a href="#main" class="skip-link">Přejít na hlavní obsah</a>

    <!-- ═══ NAVIGACE ═══ -->
    <header class="fixed top-0 inset-x-0 z-50 nav-bar" role="banner">
        <nav class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between"
             aria-label="Hlavní navigace">

            <!-- Logo -->
            <a href="/" class="font-display text-xl tracking-tight text-text-1 hover:text-accent transition-colors"
               aria-label="Matěj Kulíšek – úvodní stránka">
                MK<span class="text-accent">.</span>
            </a>

            <!-- Desktop menu -->
            <div class="hidden md:flex items-center gap-8">
                <a href="/"         class="<?= navActiveClass('home', $currentPage) ?>">Úvod</a>
                <a href="/sluzby"   class="<?= navActiveClass('sluzby', $currentPage) ?>">Služby</a>
                <a href="/portfolio" class="<?= navActiveClass('portfolio', $currentPage) ?>">Portfolio</a>
                <a href="/kontakt"  class="<?= navActiveClass('kontakt', $currentPage) ?>">Kontakt</a>
                <a href="/kontakt"  class="btn btn--primary text-sm !py-2 !px-5">Poptat web</a>
            </div>

            <!-- Hamburger (mobile) -->
            <button class="hamburger md:hidden relative z-50 p-2 -mr-2"
                    id="hamburger-btn" type="button"
                    aria-label="Otevřít menu" aria-expanded="false" aria-controls="mobile-menu">
                <span class="hamburger__line"></span>
                <span class="hamburger__line"></span>
                <span class="hamburger__line"></span>
            </button>
        </nav>
    </header>

    <!-- Mobile menu overlay -->
    <div class="mobile-menu" id="mobile-menu" role="dialog" aria-label="Mobilní navigace" aria-hidden="true">
        <nav class="flex flex-col items-center gap-8">
            <a href="/"         class="text-2xl font-display text-text-1 hover:text-accent transition-colors" data-mobile-link>Úvod</a>
            <a href="/sluzby"   class="text-2xl font-display text-text-1 hover:text-accent transition-colors" data-mobile-link>Služby</a>
            <a href="/portfolio" class="text-2xl font-display text-text-1 hover:text-accent transition-colors" data-mobile-link>Portfolio</a>
            <a href="/kontakt"  class="text-2xl font-display text-text-1 hover:text-accent transition-colors" data-mobile-link>Kontakt</a>
            <a href="/kontakt"  class="btn btn--primary mt-4" data-mobile-link>Poptat web</a>
        </nav>
    </div>

    <!-- ═══ HLAVNÍ OBSAH ═══ -->
    <main id="main">
