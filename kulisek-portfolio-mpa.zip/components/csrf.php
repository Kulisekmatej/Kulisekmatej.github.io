<?php
/**
 * components/csrf.php – Správa CSRF tokenů
 *
 * MECHANISMUS:
 * 1. Při prvním načtení stránky se vygeneruje kryptograficky bezpečný token
 * 2. Token se uloží do $_SESSION a zároveň vloží do skrytého pole formuláře
 * 3. Při odeslání formuláře server porovná tokeny (timing-safe)
 * 4. Po úspěšném odeslání se token regeneruje (single-use → replay prevence)
 *
 * BEZPEČNOST: random_bytes() používá CSPRNG operačního systému.
 */

declare(strict_types=1);

// Session konfigurace – hardened cookies
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,     // JS nemůže číst cookie → XSS ochrana
        'cookie_secure'   => true,     // Cookie jen přes HTTPS
        'cookie_samesite' => 'Strict', // Nepošle se v cross-site requestech → CSRF ochrana
        'use_strict_mode' => true,     // Odmítne neznámé session ID
    ]);
}

// Vygeneruj token pokud neexistuje
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/** Vrátí aktuální CSRF token pro vložení do formuláře */
function getCsrfToken(): string
{
    return $_SESSION['csrf_token'];
}

/** Ověří odeslaný CSRF token (timing-safe porovnání) */
function verifyCsrfToken(string $token): bool
{
    if (empty($_SESSION['csrf_token'])) {
        return false;
    }
    // hash_equals() → konstantní čas porovnání, zabraňuje timing side-channel útoku
    return hash_equals($_SESSION['csrf_token'], $token);
}

/** Regeneruje token po úspěšném použití (single-use) */
function regenerateCsrfToken(): void
{
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
