    </main>
    <!-- ═══ /HLAVNÍ OBSAH ═══ -->

    <!-- ═══ FOOTER ═══ -->
    <footer class="border-t border-border-1 py-12 mt-24" role="contentinfo">
        <div class="max-w-6xl mx-auto px-6">

            <!-- Horní část footeru -->
            <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">

                <!-- Značka -->
                <div class="lg:col-span-2">
                    <a href="/" class="font-display text-2xl text-text-1 inline-block mb-3">
                        MK<span class="text-accent">.</span>
                    </a>
                    <p class="text-text-2 text-sm max-w-sm leading-relaxed">
                        Tvořím rychlé, bezpečné a SEO-optimalizované weby,
                        které přinášejí zákazníky. Žádné šablony — vše na míru.
                    </p>
                </div>

                <!-- Navigace -->
                <div>
                    <h3 class="font-mono text-xs text-text-3 uppercase tracking-widest mb-4">Navigace</h3>
                    <ul class="space-y-2.5 text-sm">
                        <li><a href="/"          class="text-text-2 hover:text-text-1 transition-colors">Úvod</a></li>
                        <li><a href="/sluzby"    class="text-text-2 hover:text-text-1 transition-colors">Služby</a></li>
                        <li><a href="/portfolio" class="text-text-2 hover:text-text-1 transition-colors">Portfolio</a></li>
                        <li><a href="/kontakt"   class="text-text-2 hover:text-text-1 transition-colors">Kontakt</a></li>
                    </ul>
                </div>

                <!-- Kontakt -->
                <div>
                    <h3 class="font-mono text-xs text-text-3 uppercase tracking-widest mb-4">Kontakt</h3>
                    <ul class="space-y-2.5 text-sm">
                        <li>
                            <a href="mailto:matej.kulisek99@icloud.com"
                               class="text-text-2 hover:text-accent transition-colors">
                                matej.kulisek99@icloud.com
                            </a>
                        </li>
                        <li>
                            <a href="https://github.com/Kulisekmatej" target="_blank" rel="noopener noreferrer"
                               class="text-text-2 hover:text-accent transition-colors">
                                GitHub
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Spodní linie -->
            <div class="border-t border-border-1 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-text-3">
                <p>&copy; <span id="footer-year"></span> Matěj Kulíšek · OSVČ</p>
                <p class="flex items-center gap-1.5">
                    <span class="inline-block w-1.5 h-1.5 rounded-full bg-accent animate-pulse" aria-hidden="true"></span>
                    CCNA · CompTIA Security+
                </p>
            </div>
        </div>
    </footer>

    <!-- Toast notifikace (formulář) -->
    <div id="toast" class="toast" role="status" aria-live="polite" aria-atomic="true"></div>

    <!-- JavaScript – defer = nechá HTML zparsovat první → lepší LCP -->
    <script src="/assets/js/main.js" defer></script>
</body>
</html>
