<?php
/**
 * portfolio.php – Kompletní přehled projektů (Case Studies)
 *
 * URL: /portfolio
 * ARCHITEKTURA: Data definovaná v PHP poli → renderovaná v šabloně.
 * Snadné přidání nového projektu = přidat prvek do pole $projects.
 */

$pageTitle       = 'Portfolio | Matěj Kulíšek';
$pageDescription = 'Přehled dokončených projektů: firemní weby, bezpečnostní audity a landing pages. Problém → Řešení → Výsledek.';
$currentPage     = 'portfolio';

require_once __DIR__ . '/components/header.php';

// ─── DATA: Projekty ─────────────────────────────────────────────
$projects = [
    [
        'category'   => 'Firemní web',
        'title'      => 'Airless Malby Kreisinger',
        'gradient'   => 'from-accent/10 to-transparent',
        'tags'       => ['HTML5', 'CSS3', 'JavaScript', 'SEO'],
        'problem'    => 'Malířská firma bez online prezentace přicházela o zakázky. Zákazníci nemohli najít kontakt ani reference.',
        'solution'   => 'Navrhl a vyvinul responzivní web s důrazem na lokální SEO, Google Business profil a rychlý kontaktní formulář.',
        'result'     => 'Firma je viditelná v lokálním vyhledávání. Poptávky přes web narostly z nuly na 12+ měsíčně.',
        'metrics'    => [
            ['value' => '96+', 'label' => 'Lighthouse'],
            ['value' => '<1.5s', 'label' => 'Načtení'],
            ['value' => '12+',  'label' => 'Poptávek/m'],
        ],
        'imageAlt'   => 'Náhled webové stránky Airless Malby Kreisinger',
    ],
    [
        'category'   => 'Cybersecurity',
        'title'      => 'Bezpečnostní audit – škola',
        'gradient'   => 'from-red-500/10 to-transparent',
        'tags'       => ['Kali Linux', 'Nmap', 'Burp Suite', 'OWASP'],
        'problem'    => 'Školní Joomla web s neznámým bezpečnostním stavem. Vedení potřebovalo audit před GDPR revizí.',
        'solution'   => 'Provedl autorizovaný penetrační test. Identifikoval zranitelnosti a připravil detailní report s doporučeními.',
        'result'     => 'Všech 7 zranitelností opraveno, včetně 2 kritických. Škola získala dokumentaci pro GDPR compliance.',
        'metrics'    => [
            ['value' => '7', 'label' => 'Nálezy'],
            ['value' => '2', 'label' => 'Kritické'],
            ['value' => '100%', 'label' => 'Opraveno'],
        ],
        'imageAlt'   => 'Dashboard bezpečnostního auditu školního webu',
    ],
    [
        'category'   => 'Landing Page',
        'title'      => 'Osobní portfolio',
        'gradient'   => 'from-blue-500/10 to-transparent',
        'tags'       => ['HTML5', 'JS', 'GitHub Pages', 'Cloudflare'],
        'problem'    => 'Potřeba profesionální online prezentace pro freelance IT podnikání s důrazem na certifikace.',
        'solution'   => 'Moderní portfolio s GitHub Pages, Cloudflare DNS a optimalizovaným výkonem.',
        'result'     => 'Profesionální vizitka generující organické poptávky. +340 % trafficu, bounce rate 22 %.',
        'metrics'    => [
            ['value' => '98',    'label' => 'PageSpeed'],
            ['value' => '+340%', 'label' => 'Traffic'],
            ['value' => '22%',   'label' => 'Bounce'],
        ],
        'imageAlt'   => 'Náhled osobního portfolio webu',
    ],
];
?>

<!-- ═══ HERO ═══ -->
<section class="pt-32 pb-20" aria-labelledby="portfolio-heading">
    <div class="max-w-6xl mx-auto px-6">
        <div data-reveal class="max-w-2xl">
            <hr class="section-line mb-6" aria-hidden="true">
            <h1 id="portfolio-heading" class="font-display text-4xl sm:text-5xl md:text-6xl leading-tight mb-5">
                Projekty, které<br><span class="italic text-accent">mluví za vše</span>
            </h1>
            <p class="text-text-2 text-lg leading-relaxed">
                Každý projekt řeším jako business problém — ne jen jako kód.
                Měřím výsledky, ne pixely.
            </p>
        </div>
    </div>
</section>

<!-- ═══ PROJEKTY GRID ═══ -->
<section class="pb-24 sm:pb-32" aria-label="Přehled projektů">
    <div class="max-w-6xl mx-auto px-6">
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            <?php foreach ($projects as $i => $proj): ?>
            <article data-reveal data-reveal-delay="<?= min($i + 1, 3) ?>"
                     class="card flex flex-col">

                <!-- Náhled (placeholder gradient) -->
                <div class="aspect-video rounded-lg mb-5 bg-surface-3 relative overflow-hidden"
                     role="img" aria-label="<?= htmlspecialchars($proj['imageAlt'], ENT_QUOTES, 'UTF-8') ?>">
                    <div class="absolute inset-0 bg-gradient-to-br <?= $proj['gradient'] ?>"></div>
                    <div class="absolute bottom-3 left-3 flex flex-wrap gap-1.5">
                        <?php foreach ($proj['tags'] as $tag): ?>
                        <span class="badge text-[10px]"><?= htmlspecialchars($tag) ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Kategorie + titulek -->
                <span class="badge badge--accent text-[10px] mb-3"><?= htmlspecialchars($proj['category']) ?></span>
                <h2 class="font-display text-xl mb-4"><?= htmlspecialchars($proj['title']) ?></h2>

                <!-- Problém → Řešení → Výsledek -->
                <div class="space-y-3 text-sm text-text-2 flex-grow">
                    <div>
                        <span class="font-mono text-[10px] text-text-3 uppercase tracking-widest">Problém</span>
                        <p class="mt-1"><?= htmlspecialchars($proj['problem']) ?></p>
                    </div>
                    <div>
                        <span class="font-mono text-[10px] text-text-3 uppercase tracking-widest">Řešení</span>
                        <p class="mt-1"><?= htmlspecialchars($proj['solution']) ?></p>
                    </div>
                    <div>
                        <span class="font-mono text-[10px] text-text-3 uppercase tracking-widest">Výsledek</span>
                        <p class="mt-1"><?= htmlspecialchars($proj['result']) ?></p>
                    </div>
                </div>

                <!-- Metriky -->
                <div class="grid grid-cols-3 gap-3 mt-5 pt-5 border-t border-border-1">
                    <?php foreach ($proj['metrics'] as $m): ?>
                    <div class="text-center">
                        <div class="metric text-lg"><?= htmlspecialchars($m['value']) ?></div>
                        <div class="text-[11px] text-text-3 mt-0.5"><?= htmlspecialchars($m['label']) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </article>
            <?php endforeach; ?>

        </div>
    </div>
</section>

<!-- CTA -->
<section class="py-20 border-t border-border-1" aria-labelledby="cta-portfolio-heading">
    <div data-reveal class="max-w-3xl mx-auto px-6 text-center">
        <h2 id="cta-portfolio-heading" class="font-display text-3xl sm:text-4xl leading-tight mb-4">
            Chcete podobné <span class="italic text-accent">výsledky?</span>
        </h2>
        <p class="text-text-2 text-lg mb-8">Popište svůj projekt a společně ho dotáhneme do konce.</p>
        <a href="/kontakt" class="btn btn--primary text-base">Nezávazná poptávka</a>
    </div>
</section>

<?php require_once __DIR__ . '/components/footer.php'; ?>
