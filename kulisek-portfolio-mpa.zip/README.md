# Matěj Kulíšek – Portfolio (Multi-Page PHP)

## 📁 Stromová struktura projektu

```
kulisekmatej.cz/
│
├── .htaccess                 ← Apache: HTTPS, čisté URL, bezpečnostní hlavičky, cache
│
├── index.php                 ← Hlavní stránka (hero, 3 služby, 2 projekty, CTA)
├── sluzby.php                ← Detailní ceník a proces spolupráce
├── portfolio.php             ← Kompletní grid case studies
├── kontakt.php               ← Kontaktní formulář (CSRF + honeypot)
├── process.php               ← Backend: validace, sanitizace, rate limit, mail()
│
├── components/
│   ├── header.php            ← Sdílená hlavička (<head>, nav, otevírací <main>)
│   ├── footer.php            ← Sdílená patička (footer, toast, </main>, JS)
│   └── csrf.php              ← CSRF token manager (session-based)
│
├── assets/
│   ├── css/
│   │   └── style.css         ← Design systém: tokeny, animace, komponenty
│   ├── js/
│   │   └── main.js           ← Formulář, animace, mobilní menu (< 7 KB)
│   ├── icons/
│   │   └── favicon.svg       ← MK monogram
│   └── images/               ← Screenshoty projektů (.webp)
│
└── README.md
```

## 🏗️ Architektura

**Modulární PHP šablonování:**
```
index.php           → require_once header.php
                    → vlastní obsah stránky
                    → require_once footer.php
```

Každá stránka nastaví 3 proměnné (`$pageTitle`, `$pageDescription`, `$currentPage`)
a pak includuje header. Header z nich vygeneruje `<head>` meta tagy a zvýrazní
aktivní odkaz v navigaci.

**Čisté URL (.htaccess):**
```
/kontakt     → interně přepíše na /kontakt.php
/kontakt.php → 301 redirect na /kontakt (SEO kanonizace)
```

## 🚀 Nasazení na WEDOS

### 1. Příprava
- Aktivuj SSL certifikát (Let's Encrypt) v administraci WEDOS
- Ověř PHP 8.x (Administrace → PHP nastavení)
- Ověř, že `mail()` je povolena

### 2. Upload
1. Připoj se přes SFTP (FileZilla, port 22)
2. Nahraj **vše** do kořenového adresáře `/www/`
3. `.htaccess` MUSÍ být v kořeni

### 3. Konfigurace
```php
// V process.php uprav:
const RECIPIENT_EMAIL = 'tvuj@email.cz';
const SENDER_EMAIL    = 'noreply@tvadomena.cz';
```

### 4. Ověření
- [ ] HTTPS funguje (zelený zámek)
- [ ] Čisté URL (`/kontakt` místo `/kontakt.php`)
- [ ] Formulář odesílá e-mail
- [ ] [securityheaders.com](https://securityheaders.com/) → cíl A+
- [ ] [PageSpeed Insights](https://pagespeed.web.dev/) → cíl 90+

## 🔒 Bezpečnostní architektura

| Vrstva           | Mechanismus                                 | Soubor              |
|------------------|---------------------------------------------|---------------------|
| Transport        | HTTPS (TLS) + HSTS                          | `.htaccess`         |
| HTTP hlavičky    | CSP, X-Frame, X-Content-Type, Referrer      | `.htaccess`         |
| URL obfuskace    | Skrytí .php koncovek                        | `.htaccess`         |
| Anti-spam        | Honeypot (off-screen skryté pole)           | `kontakt.php` + PHP |
| CSRF             | Session token (single-use, timing-safe)     | `csrf.php`          |
| Validace         | Klient (JS UX) + Server (PHP autorita)      | `main.js` + PHP     |
| Sanitizace       | `htmlspecialchars()` + `filter_var()`       | `process.php`       |
| Rate limiting    | Session sliding window (3/hod)              | `process.php`       |
| Soubory          | Zakázání indexu + blokování .env/.log       | `.htaccess`         |

## ⚡ Optimalizace Tailwind (volitelné)

CDN = ~300 KB. Pro produkci zkompiluj:

```bash
npm install -D tailwindcss
npx tailwindcss -o assets/css/tailwind.min.css \
  --content "./**/*.php" --minify
```

V `header.php` nahraď CDN `<script>` za `<link>` na zkompilovaný soubor.
