<?php
/**
 * kontakt.php – Kontaktní stránka s bezpečným formulářem
 *
 * URL: /kontakt
 * BEZPEČNOST:
 *   - CSRF token (vygenerovaný v header.php → csrf.php)
 *   - Honeypot skryté pole (anti-bot)
 *   - Klientská validace (JS) + serverová validace (process.php)
 *   - Asynchronní odeslání (fetch API, bez reload)
 */

$pageTitle       = 'Kontakt | Matěj Kulíšek';
$pageDescription = 'Poptejte web, konzultaci nebo bezpečnostní audit. Odpovím do 24 hodin.';
$currentPage     = 'kontakt';

require_once __DIR__ . '/components/header.php';
?>

<section class="pt-32 pb-24 sm:pb-32" aria-labelledby="kontakt-heading">
    <div class="max-w-6xl mx-auto px-6">
        <div class="grid lg:grid-cols-2 gap-12 lg:gap-20">

            <!-- ═══ LEVÁ STRANA – info ═══ -->
            <div data-reveal>
                <hr class="section-line mb-6" aria-hidden="true">
                <h1 id="kontakt-heading" class="font-display text-4xl sm:text-5xl md:text-6xl leading-tight mb-5">
                    Máte projekt?<br>
                    <span class="italic text-accent">Pojďme to řešit</span>
                </h1>
                <p class="text-text-2 text-lg leading-relaxed mb-10">
                    Popište svou představu a do 24&nbsp;hodin se vám ozvu
                    s&nbsp;nezávaznou nabídkou. Žádné poplatky za konzultaci.
                </p>

                <!-- Kontaktní info -->
                <div class="space-y-5">
                    <div class="flex items-center gap-4">
                        <div class="w-11 h-11 rounded-lg bg-surface-3 flex items-center justify-center shrink-0" aria-hidden="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="1.5" class="text-accent">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                        </div>
                        <div>
                            <div class="text-text-3 text-xs font-mono uppercase tracking-wider">E-mail</div>
                            <a href="mailto:matej.kulisek99@icloud.com"
                               class="text-text-1 hover:text-accent transition-colors text-sm">
                                matej.kulisek99@icloud.com
                            </a>
                        </div>
                    </div>
                    <div class="flex items-center gap-4">
                        <div class="w-11 h-11 rounded-lg bg-surface-3 flex items-center justify-center shrink-0" aria-hidden="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="1.5" class="text-accent">
                                <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/>
                            </svg>
                        </div>
                        <div>
                            <div class="text-text-3 text-xs font-mono uppercase tracking-wider">GitHub</div>
                            <a href="https://github.com/Kulisekmatej" target="_blank" rel="noopener noreferrer"
                               class="text-text-1 hover:text-accent transition-colors text-sm">
                                github.com/Kulisekmatej
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Micro-certifikace -->
                <div class="mt-10 flex flex-wrap gap-2">
                    <span class="badge">CCNA</span>
                    <span class="badge">CompTIA Security+</span>
                    <span class="badge">OWASP</span>
                    <span class="badge">Kali Linux</span>
                </div>
            </div>

            <!-- ═══ PRAVÁ STRANA – formulář ═══ -->
            <div data-reveal data-reveal-delay="1">
                <form id="contact-form"
                      action="/process.php"
                      method="POST"
                      class="space-y-5"
                      novalidate
                      aria-label="Kontaktní formulář pro poptávku">

                    <!-- CSRF TOKEN -->
                    <input type="hidden" name="csrf_token"
                           value="<?= htmlspecialchars(getCsrfToken(), ENT_QUOTES, 'UTF-8') ?>">

                    <!-- ╔══════════════════════════════════════════════╗
                         ║ HONEYPOT – skryté anti-spam pole             ║
                         ║ CSS ho posune mimo viewport.                 ║
                         ║ Bot ho vyplní → server tiše odmítne.         ║
                         ║ tabindex=-1 → klávesnice přeskočí.           ║
                         ╚══════════════════════════════════════════════╝ -->
                    <div class="hp-field" aria-hidden="true">
                        <label for="website_url">URL webu</label>
                        <input type="text" id="website_url" name="website_url"
                               tabindex="-1" autocomplete="off">
                    </div>

                    <!-- Jméno -->
                    <div>
                        <label for="name" class="form-label">
                            Jméno <span class="text-accent" aria-hidden="true">*</span>
                            <span class="sr-only">(povinné)</span>
                        </label>
                        <input type="text" id="name" name="name" class="form-field"
                               placeholder="Jan Novák"
                               required minlength="2" maxlength="100" autocomplete="name"
                               aria-describedby="name-error" aria-invalid="false">
                        <p id="name-error" class="form-error" role="alert"></p>
                    </div>

                    <!-- E-mail -->
                    <div>
                        <label for="email" class="form-label">
                            E-mail <span class="text-accent" aria-hidden="true">*</span>
                            <span class="sr-only">(povinné)</span>
                        </label>
                        <input type="email" id="email" name="email" class="form-field"
                               placeholder="jan@firma.cz"
                               required maxlength="254" autocomplete="email"
                               aria-describedby="email-error" aria-invalid="false">
                        <p id="email-error" class="form-error" role="alert"></p>
                    </div>

                    <!-- Typ služby -->
                    <div>
                        <label for="service" class="form-label">
                            Typ služby <span class="text-accent" aria-hidden="true">*</span>
                            <span class="sr-only">(povinné)</span>
                        </label>
                        <select id="service" name="service" class="form-field"
                                required aria-describedby="service-error" aria-invalid="false">
                            <option value="" disabled selected>Vyberte typ projektu</option>
                            <option value="personal">Osobní web / Landing page</option>
                            <option value="business">Firemní prezentace</option>
                            <option value="eshop">E-shop řešení</option>
                            <option value="other">Jiné / Konzultace</option>
                        </select>
                        <p id="service-error" class="form-error" role="alert"></p>
                    </div>

                    <!-- Zpráva -->
                    <div>
                        <label for="message" class="form-label">
                            Zpráva <span class="text-accent" aria-hidden="true">*</span>
                            <span class="sr-only">(povinné)</span>
                        </label>
                        <textarea id="message" name="message" class="form-field" rows="5"
                                  placeholder="Popište svůj projekt – co potřebujete, jaký máte rozpočet a termín..."
                                  required minlength="10" maxlength="5000"
                                  aria-describedby="message-error message-counter"
                                  aria-invalid="false"></textarea>
                        <div class="flex justify-between items-center mt-1">
                            <p id="message-error" class="form-error" role="alert"></p>
                            <span id="message-counter" class="text-[11px] text-text-3 font-mono" aria-live="polite">0 / 5000</span>
                        </div>
                    </div>

                    <!-- Submit -->
                    <button type="submit" id="submit-btn" class="btn btn--primary btn--full text-base mt-2">
                        <span id="submit-text">Odeslat poptávku</span>
                        <span id="submit-spinner" class="spinner hidden" aria-hidden="true"></span>
                    </button>

                    <p class="text-[11px] text-text-3 text-center mt-3">
                        Odesláním souhlasíte se zpracováním údajů za účelem odpovědi na poptávku.
                    </p>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/components/footer.php'; ?>
